<?php
/**
 * Package prefix for autoloader.
 */
$loader->add('Aura\Router\\', dirname(__DIR__) . DIRECTORY_SEPARATOR . 'tests');
